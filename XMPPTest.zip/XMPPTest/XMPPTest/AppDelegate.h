//
//  AppDelegate.h
//  XMPPTest
//
//  Created by yuzhijun on 14-12-29.
//  Copyright (c) 2014年 yuzhijun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XMPP.h"


@interface AppDelegate : UIResponder <UIApplicationDelegate>{
  
}

@property (strong, nonatomic) UIWindow *window;

@end
