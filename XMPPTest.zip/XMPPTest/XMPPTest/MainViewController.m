//
//  MainViewController.m
//  XMPPTest
//
//  Created by yuzhijun on 14-12-29.
//  Copyright (c) 2014年 yuzhijun. All rights reserved.
//

#import "MainViewController.h"

@implementation MainViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIButton *loginbutton = [[UIButton alloc] initWithFrame:CGRectMake(50, 80, 200, 30)];
    [loginbutton setBackgroundColor:[UIColor grayColor]];
    [loginbutton setTitle:@"登陆" forState:UIControlStateNormal];
    [loginbutton addTarget:self action:@selector(loginbuttonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginbutton];
    
    UIButton *registerbutton = [[UIButton alloc] initWithFrame:CGRectMake(50, loginbutton.frame.origin.y + loginbutton.frame.size.height + 20, 200, 30)];
    [registerbutton setBackgroundColor:[UIColor grayColor]];
    [registerbutton setTitle:@"注册" forState:UIControlStateNormal];
    [registerbutton addTarget:self action:@selector(registerbuttonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:registerbutton];
    
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(50, registerbutton.frame.origin.y + registerbutton.frame.size.height + 20, 200, 30)];
    [button setBackgroundColor:[UIColor grayColor]];
    [button setTitle:@"退出登陆" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    UIButton *sendbutton = [[UIButton alloc] initWithFrame:CGRectMake(50, button.frame.origin.y + button.frame.size.height + 20, 200, 30)];
    [sendbutton setBackgroundColor:[UIColor grayColor]];
    [sendbutton setTitle:@"发送消息" forState:UIControlStateNormal];
    [sendbutton addTarget:self action:@selector(sendbuttonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sendbutton];
    
    UIButton *rosterbutton = [[UIButton alloc] initWithFrame:CGRectMake(50, sendbutton.frame.origin.y + sendbutton.frame.size.height + 20, 200, 30)];
    [rosterbutton setBackgroundColor:[UIColor grayColor]];
    [rosterbutton setTitle:@"获取好友列表" forState:UIControlStateNormal];
    [rosterbutton addTarget:self action:@selector(rosterbuttonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:rosterbutton];
    
    
    UIButton *roombutton = [[UIButton alloc] initWithFrame:CGRectMake(50, rosterbutton.frame.origin.y + rosterbutton.frame.size.height + 20, 200, 30)];
    [roombutton setBackgroundColor:[UIColor grayColor]];
    [roombutton setTitle:@"创建房间" forState:UIControlStateNormal];
    [roombutton addTarget:self action:@selector(roombuttonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:roombutton];
    
    UIButton *addFriendbutton = [[UIButton alloc] initWithFrame:CGRectMake(50, roombutton.frame.origin.y + roombutton.frame.size.height + 20, 200, 30)];
    [addFriendbutton setBackgroundColor:[UIColor grayColor]];
    [addFriendbutton setTitle:@"添加好友" forState:UIControlStateNormal];
    [addFriendbutton addTarget:self action:@selector(addFriendbuttonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:addFriendbutton];
    
    UIButton *addAllRoombutton = [[UIButton alloc] initWithFrame:CGRectMake(50, addFriendbutton.frame.origin.y + addFriendbutton.frame.size.height + 20, 200, 30)];
    [addAllRoombutton setBackgroundColor:[UIColor grayColor]];
    [addAllRoombutton setTitle:@"获取所有房间" forState:UIControlStateNormal];
    [addAllRoombutton addTarget:self action:@selector(addAllRoombuttonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:addAllRoombutton];
    
    
    defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:@"test2" forKey:@"USERNAME"];
    [defaults setObject:@"123456" forKey:@"PASSWORD"];
    [defaults setObject:@"10.11.74.6" forKey:@"SERVER"];
    [defaults synchronize];
    
    xmppsingle = [XMPPSingle sharedInstance];
    xmppRooms = [XMPPRooms sharedInstance];
    
    [xmppsingle setupStream];
   
}

-(void)loginbuttonClick{
    [defaults setObject:@"register" forKey:@""];
     [xmppsingle connect];
      NSLog(@"%@",@"登陆");
}

-(void)registerbuttonClick{
    [defaults setObject:@"register" forKey:@"REGISTER"];
    [xmppsingle connect];
    NSLog(@"%@",@"注册");
}

-(void)buttonClick{
    NSLog(@"%@",@"退出登陆");
    [xmppsingle disconnect];
    [xmppRooms leftRoom];
}

-(void)sendbuttonClick{
//    [self sendMessage:@"中文" toUser:@"linhao@lenovopush"];
    [self sendGroupMessage:@"group中文"];
//    [self sendBroadcastMessage:@"广播"];
}

-(void)rosterbuttonClick{
    [self queryRoster];
//    [self queryRosterGroup];
}

-(void)roombuttonClick{
//    [xmppRooms joinRoom];
    [xmppRooms createRoom];
}

-(void)addFriendbuttonClick{
    [xmppsingle xmppAddFriendSubscribe:@"test1"];
}

-(void)addAllRoombuttonClick{
    [self queryAllRooms];
}
//发送点对点消息
/*
 <message type="chat" to="xiaoming@example.com">
 
 　　<body>Hello World!<body />
 
 <message />
 */
- (void)sendMessage:(NSString *) message toUser:(NSString *)user {
    //生成文档
    NSXMLElement *body = [NSXMLElement elementWithName:@"body"];
    [body setStringValue:message];
    //生成XML消息文档
    NSXMLElement *messageElement = [NSXMLElement elementWithName:@"message"];
    //消息类型
    [messageElement addAttributeWithName:@"type" stringValue:@"chat"];
    //发送给谁
    [messageElement addAttributeWithName:@"to" stringValue:user];
    //由谁发送
    [messageElement addAttributeWithName:@"from" stringValue:@"test"];
    //组合
    [messageElement addChild:body];
    //发送消息
    [[xmppsingle xmppStream] sendElement:messageElement];
}
//发送组消息
/*
 <message type="groupchat" to="room2@conference.lenovopush">
 
 　　<body>Hello World!<body />
 
 <message />
 */
- (void)sendGroupMessage:(NSString *) message{
    //生成文档
    NSXMLElement *body = [NSXMLElement elementWithName:@"body"];
    [body setStringValue:message];
    //生成XML消息文档
    NSXMLElement *messageElement = [NSXMLElement elementWithName:@"message"];
    //消息类型
    [messageElement addAttributeWithName:@"type" stringValue:@"groupchat"];
    //发送给谁
    [messageElement addAttributeWithName:@"to" stringValue:@"room3@conference.lenovopush"];
    //由谁发送
    [messageElement addAttributeWithName:@"from" stringValue:@"test1"];
    //组合
    [messageElement addChild:body];
    //发送消息
    [[xmppsingle xmppStream] sendElement:messageElement];
}

- (void)sendBroadcastMessage:(NSString *) message{
    //生成文档
    NSXMLElement *body = [NSXMLElement elementWithName:@"body"];
    [body setStringValue:message];
    //生成XML消息文档
    NSXMLElement *messageElement = [NSXMLElement elementWithName:@"message"];
    //消息类型
    [messageElement addAttributeWithName:@"type" stringValue:@"chat"];
    //发送给谁
    [messageElement addAttributeWithName:@"to" stringValue:@"all@lenovopush"];
    //由谁发送
    [messageElement addAttributeWithName:@"from" stringValue:@"test"];
    //组合
    [messageElement addChild:body];
    //发送消息
    [[xmppsingle xmppStream] sendElement:messageElement];
}


//查找花名册
/*
 一个 IQ 请求：
 
 <iq type="get"
 
 　　from="xiaoming@example.com"
 
 　　to="example.com"
 
 　　id="1234567">
 
 　　<query xmlns="jabber:iq:roster"/>
 
 <iq />
 
 type 属性，说明了该 iq 的类型为 get，与 HTTP 类似，向服务器端请求信息
 
 from 属性，消息来源，这里是你的 JID
 
 to 属性，消息目标，这里是服务器域名
 
 id 属性，标记该请求 ID，当服务器处理完毕请求 get 类型的 iq 后，响应的 result 类型 iq 的 ID 与 请求 iq 的 ID 相同
 
 <query xmlns="jabber:iq:roster"/> 子标签，说明了客户端需要查询 roster
 */
- (void)queryRoster {
    NSXMLElement *query = [NSXMLElement elementWithName:@"query" xmlns:@"jabber:iq:roster"];
    NSXMLElement *iq = [NSXMLElement elementWithName:@"iq"];
    XMPPJID *myJID = xmppsingle.xmppStream.myJID;
    [iq addAttributeWithName:@"from" stringValue:myJID.description];
    [iq addAttributeWithName:@"to" stringValue:myJID.domain];
    [iq addAttributeWithName:@"id" stringValue:@"1234567"];
    [iq addAttributeWithName:@"type" stringValue:@"get"];
    [iq addChild:query];
    [[xmppsingle xmppStream] sendElement:iq];
}
/*
<iq type="get" from="test1@lenovopush/b0f10cb4" to="conference.lenovopush" id="1234567"><query xmlns="http://jabber.org/protocol/disco#items"/></iq>
 */
//查找所有的房间
-(void)queryAllRooms{
    XMPPJID *myJID = xmppsingle.xmppStream.myJID;
    NSXMLElement *queryElement= [NSXMLElement elementWithName:@"query" xmlns:@"http://jabber.org/protocol/disco#items"];
    NSXMLElement *iqElement = [NSXMLElement elementWithName:@"iq"];
    [iqElement addAttributeWithName:@"type" stringValue:@"get"];
    [iqElement addAttributeWithName:@"from" stringValue:myJID.description];
    [iqElement addAttributeWithName:@"to" stringValue:@"conference.lenovopush"];
    [iqElement addAttributeWithName:@"id" stringValue:@"1234567"];
    [iqElement addChild:queryElement];
    [[xmppsingle xmppStream] sendElement:iqElement];
}

//-(void)queryRosterGroup{
//    NSXMLElement *query = [NSXMLElement elementWithName:@"query" xmlns:@"jabber:iq:roster"];
//    
//    NSXMLElement *iq = [NSXMLElement elementWithName:@"iq"];
//    XMPPJID *myJID = xmppsingle.xmppStream.myJID;
//    
//    NSXMLElement *item = [NSXMLElement elementWithName:@"item"];
//    [item addAttributeWithName:@"jid" stringValue:myJID.description];
//    
//    NSXMLElement *groupElement = [NSXMLElement elementWithName:@"group"];
//    [groupElement setStringValue:@"group1"];
//    [item addChild:groupElement];
//    
//    [query addChild:item];
//    
//    [iq addAttributeWithName:@"from" stringValue:myJID.description];
//    [iq addAttributeWithName:@"to" stringValue:myJID.domain];
//    [iq addAttributeWithName:@"id" stringValue:@"1234567"];
//    [iq addAttributeWithName:@"type" stringValue:@"get"];
//    [iq addChild:query];
//    [[xmppsingle xmppStream] sendElement:iq];
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
