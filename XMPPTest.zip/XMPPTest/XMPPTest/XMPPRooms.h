//
//  XMPPRoom.h
//  XMPPTest
//
//  Created by yuzhijun on 14-12-30.
//  Copyright (c) 2014年 yuzhijun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMPPRoomCoreDataStorage.h"

@interface XMPPRooms : NSObject
{
    XMPPRoom        *xmppRoom;
    BOOL            isNew;
    NSString        *roomjid;
    NSUserDefaults  *userDefaults;
    XMPPRoomCoreDataStorage *roomStorage;
}
@property (nonatomic,copy) NSString *roomName;//房间名称
@property (nonatomic,copy) NSString *roomTitle;//房间主题
@property (nonatomic,copy) NSString *roomNickName;//房间昵称
@property (nonatomic,retain) XMPPRoom *xmppRoom;
+(XMPPRooms *)sharedInstance;
//初始化聊天室
-(void)joinRoom;
//创建房间
-(void)createRoom;
//离开房间
-(void)leftRoom;
@end
