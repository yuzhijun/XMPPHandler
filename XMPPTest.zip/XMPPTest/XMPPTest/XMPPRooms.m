//
//  XMPPRoom.m
//  XMPPTest
//
//  Created by yuzhijun on 14-12-30.
//  Copyright (c) 2014年 yuzhijun. All rights reserved.
//

#import "XMPPRooms.h"
#import "XMPPSingle.h"

@implementation XMPPRooms
@synthesize roomName;
@synthesize roomTitle;
@synthesize roomNickName;
@synthesize xmppRoom;

-(id)init{
    self = [super init];
    if (self) {
        roomName = @"ROOM3";
        roomTitle = @"BIRTHDAY";
        roomNickName = @"ICE-NIGHT";
        roomStorage = [[XMPPRoomCoreDataStorage alloc] init];
    }
    return self;
}

static XMPPRooms *sharedManager;
+(XMPPRooms *)sharedInstance{
    if (sharedManager == nil) {
        sharedManager = [[XMPPRooms alloc] init];
    }
    return sharedManager;
}

//初始化聊天室
-(void)joinRoom{
    isNew = NO;
    roomjid = [NSString stringWithFormat:@"%@@conference.lenovopush",roomName];
    xmppRoom = [[XMPPRoom alloc] initWithRoomStorage:roomStorage jid:[XMPPJID jidWithString:roomjid] dispatchQueue:dispatch_get_main_queue()];
    [xmppRoom activate:[XMPPSingle sharedInstance].xmppStream];
    [xmppRoom joinRoomUsingNickname:roomNickName history:nil];
    [xmppRoom addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [self noSendHistory];
}

//创建房间
-(void)createRoom{
    isNew = YES;
    roomjid = [NSString stringWithFormat:@"%@@conference.lenovopush",roomName];
    xmppRoom = [[XMPPRoom alloc] initWithRoomStorage:roomStorage jid:[XMPPJID jidWithString:roomjid] dispatchQueue:dispatch_get_main_queue()];
    [xmppRoom activate:[XMPPSingle sharedInstance].xmppStream];
    [xmppRoom joinRoomUsingNickname:roomNickName history:nil];
    [xmppRoom addDelegate:self delegateQueue:dispatch_get_main_queue()];
}

#pragma mark -委托
//创建结果
- (void)xmppRoomDidCreate:(XMPPRoom *)sender{
    NSLog(@"xmppRoomDidCreate");
    [xmppRoom changeRoomSubject:roomTitle];
//        [_xmppRoom fetchMembersList1:self.roomName];
}
//是否已经加入房间
- (void)xmppRoomDidJoin:(XMPPRoom *)sender{
    NSLog(@"xmppRoomDidJoin");
    if(isNew){
        [self configNewRoom];
    }else{
        [self noSendHistory];
        [xmppRoom configureRoomUsingOptions:nil];
        [xmppRoom fetchConfigurationForm];
    }
    [xmppRoom fetchMembersList];
    [xmppRoom fetchModeratorsList];
    [self changePrivilege];
}

-(void)changePrivilege{
    NSMutableArray *items = [[NSMutableArray alloc] initWithCapacity:1];
    NSXMLElement *item = [NSXMLElement elementWithName:@"item"];
    [item addAttributeWithName:@"jid" stringValue:@"test1@lenovopush"];
    [item addAttributeWithName:@"affiliation" stringValue:@"member"];
    [items addObject:item];
    [xmppRoom editRoomPrivileges:items];
}

//是否已经离开
-(void)xmppRoomDidLeave:(XMPPRoom *)sender{
    NSLog(@"xmppRoomDidLeave");
}

//离开房间
-(void)leftRoom{
    [xmppRoom leaveRoom];
}

//获取房间的配置表单
- (void)xmppRoom:(XMPPRoom *)sender didFetchConfigurationForm:(DDXMLElement *)configForm
{
    NSLog(@"config : %@", configForm);
    NSXMLElement *newConfig = [configForm copy];
    NSArray* fields = [newConfig elementsForName:@"field"];
    for (NSXMLElement *field in fields) {
        NSString *var = [field attributeStringValueForName:@"var"];
        if ([var isEqualToString:@"muc#roomconfig_persistentroom"]) {
            [field removeChildAtIndex:0];
            [field addChild:[NSXMLElement elementWithName:@"value" stringValue:@"1"]];
        }
    }
    [sender configureRoomUsingOptions:newConfig];
}
//接收到群消息
- (void)xmppRoom:(XMPPRoom *)sender didReceiveMessage:(XMPPMessage *)message fromOccupant:(XMPPJID *)occupantJID{
    NSLog(@"%@",@"didReceiveMessage");
}
//房间人员加入
- (void)xmppRoom:(XMPPRoom *)sender occupantDidJoin:(XMPPJID *)occupantJID withPresence:(XMPPPresence *)presence{
    NSLog(@"occupantDidJoin");
    NSString *jid = occupantJID.user;
    NSString *domain = occupantJID.domain;
    NSString *resource = occupantJID.resource;
    NSString *presenceType = [presence type];
    NSString *userId = [sender myRoomJID].user;
    NSString *presenceFromUser = [[presence from] user];
    
    NSLog(@"occupantDidJoin----jid=%@,domain=%@,resource=%@,当前用户:%@ ,出席用户:%@,presenceType:%@",jid,domain,resource,userId,presenceFromUser,presenceType);
    
    if (![presenceFromUser isEqualToString:userId]) {
        //对收到的用户的在线状态的判断在线状态
        
        //在线用户
        if ([presenceType isEqualToString:@"available"]) {
//            NSString *buddy = [NSString stringWithFormat:@"%@@lenovopush", presenceFromUser];
            //            [chatDelegate newBodyOnline:buddy];//用户列表委托
        }
        
        //用户下线
        else if ([presenceType isEqualToString:@"unavailable"]) {
            //            [chatDelegate bodyWentOffline:[NSString stringWithFormat:@"%@@%@", presenceFromUser, OpenFireHostName]];//用户列表委托
        }
    }
}
//房间人员离开
- (void)xmppRoom:(XMPPRoom *)sender occupantDidLeave:(XMPPJID *)occupantJID withPresence:(XMPPPresence *)presence{
    NSString *jid = occupantJID.user;
    NSString *domain = occupantJID.domain;
    NSString *resource = occupantJID.resource;
    NSString *presenceType = [presence type];
    NSString *userId = [sender myRoomJID].user;
    NSString *presenceFromUser = [[presence from] user];
    NSLog(@"occupantDidLeave----jid=%@,domain=%@,resource=%@,当前用户:%@ ,出席用户:%@,presenceType:%@",jid,domain,resource,userId,presenceFromUser,presenceType);
}
//房间人员加入
- (void)xmppRoom:(XMPPRoom *)sender occupantDidUpdate:(XMPPJID *)occupantJID withPresence:(XMPPPresence *)presence{
    NSString *jid = occupantJID.user;
    NSString *domain = occupantJID.domain;
    NSString *resource = occupantJID.resource;
    NSString *presenceType = [presence type];
    NSString *userId = [sender myRoomJID].user;
    NSString *presenceFromUser = [[presence from] user];
    NSLog(@"occupantDidUpdate----jid=%@,domain=%@,resource=%@,当前用户:%@ ,出席用户:%@,presenceType:%@",jid,domain,resource,userId,presenceFromUser,presenceType);
}

- (void)xmppRoom:(XMPPRoom *)sender didFetchMembersList:(NSArray *)items{
    NSLog(@"didFetchMembersList");
}

- (void)xmppRoom:(XMPPRoom *)sender didFetchModeratorsList:(NSArray *)items{
    NSLog(@"didFetchModeratorsList");
}

- (void)noSendHistory
{
    XMPPPresence* presence = [[XMPPPresence alloc] initWithType:@"" to:[XMPPJID jidWithString:roomjid]];
    NSString *myJID = [[NSUserDefaults standardUserDefaults] stringForKey:@"USERNAME"];
    [presence addAttributeWithName:@"from" stringValue:[NSString stringWithFormat:@"%@@%@",myJID,[[NSUserDefaults standardUserDefaults] stringForKey:@"SERVER"]]];
    [presence removeAttributeForName:@"type"];
    
    NSXMLElement *x = [NSXMLElement elementWithName:@"x" xmlns:@"http://jabber.org/protocol/muc"];
    NSXMLElement *history = [NSXMLElement elementWithName:@"history"];
    [history addAttributeWithName:@"maxchars" stringValue:@"0"];
    [x addChild:history];
    [presence addChild:x];
    [[XMPPSingle sharedInstance].xmppStream sendElement:presence];
}

//配置房间信息
-(void)configNewRoom{
    NSXMLElement *x = [NSXMLElement elementWithName:@"x" xmlns:@"jabber:x:data"];
    NSXMLElement *p;
    p = [NSXMLElement elementWithName:@"field" ];
    [p addAttributeWithName:@"var" stringValue:@"muc#roomconfig_persistentroom"];//永久房间
    [p addChild:[NSXMLElement elementWithName:@"value" stringValue:@"1"]];
    [x addChild:p];
    
    p = [NSXMLElement elementWithName:@"field" ];
    [p addAttributeWithName:@"var" stringValue:@"muc#roomconfig_maxusers"];//最大用户
    [p addChild:[NSXMLElement elementWithName:@"value" stringValue:@"1000"]];
    [x addChild:p];
    
    p = [NSXMLElement elementWithName:@"field" ];
    [p addAttributeWithName:@"var" stringValue:@"muc#roomconfig_changesubject"];//允许改变主题
    [p addChild:[NSXMLElement elementWithName:@"value" stringValue:@"1"]];
    [x addChild:p];
    
    p = [NSXMLElement elementWithName:@"field" ];
    [p addAttributeWithName:@"var" stringValue:@"muc#roomconfig_publicroom"];//公共房间
    [p addChild:[NSXMLElement elementWithName:@"value" stringValue:@"1"]];
    [x addChild:p];
    
    p = [NSXMLElement elementWithName:@"field" ];
    [p addAttributeWithName:@"var" stringValue:@"muc#roomconfig_allowinvites"];//允许邀请
    [p addChild:[NSXMLElement elementWithName:@"value" stringValue:@"1"]];
    [x addChild:p];
    
    /*
     p = [NSXMLElement elementWithName:@"field" ];
     [p addAttributeWithName:@"var" stringValue:@"muc#roomconfig_roomname"];//房间名称
     [p addChild:[NSXMLElement elementWithName:@"value" stringValue:self.roomTitle]];
     [x addChild:p];
     
     p = [NSXMLElement elementWithName:@"field" ];
     [p addAttributeWithName:@"var" stringValue:@"muc#roomconfig_enablelogging"];//允许登录对话
     [p addChild:[NSXMLElement elementWithName:@"value" stringValue:@"0"]];
     [x addChild:p];
     */

    
    [xmppRoom configureRoomUsingOptions:x];
}

@end
