//
//  XMPPSingle.h
//  XMPPTest
//
//  Created by yuzhijun on 14-12-30.
//  Copyright (c) 2014年 yuzhijun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMPP.h"
#import "XMPPReconnect.h"
#import "XMPPRosterCoreDataStorage.h"
#import "XMPPRoster.h"

//收到好友状态
@protocol ChatDelegate<NSObject>
-(void)newBodyOnline:(NSString *)bodyName;
-(void)bodyWentOffline:(NSString *)bodyName;
@end
//收发消息
@protocol MessageDelegate <NSObject>
-(void)newMessageReceived:(NSDictionary *)messageContent;
@end
@interface XMPPSingle : NSObject
{
    XMPPStream                  *xmppStream;
    XMPPReconnect               *xmppReconnect;
    XMPPRoster                  *xmppRoster;
    XMPPRosterCoreDataStorage   *xmppRosterStorage;
    NSUserDefaults              *userDefaults;
    NSString                    *passWord;
    BOOL                        isOpend;
}
@property (nonatomic,assign) id<ChatDelegate> chatDelegate;
@property (nonatomic,assign) id<MessageDelegate> messageDelegate;
@property (nonatomic,readonly) XMPPStream *xmppStream;
+(XMPPSingle *)sharedInstance;
//连接
-(BOOL)connect;
//设置XMPPStream
-(void)setupStream;
//断开连接
-(void)disconnect;
//上线
-(void)goOnline;
//下线
-(void)goOffline;
//添加好友
-(void)xmppAddFriendSubscribe:(NSString *)name;
@end
