//
//  XMPPSingle.m
//  XMPPTest
//
//  Created by yuzhijun on 14-12-30.
//  Copyright (c) 2014年 yuzhijun. All rights reserved.
//

#import "XMPPSingle.h"

@implementation XMPPSingle
@synthesize chatDelegate;
@synthesize messageDelegate;
@synthesize xmppStream;

static XMPPSingle *sharedManager;
+(XMPPSingle *)sharedInstance{
    if (sharedManager == nil) {
        sharedManager = [[XMPPSingle alloc] init];
    }
    return sharedManager;
}

//设置XMPPStream
-(void)setupStream{
    xmppStream = [[XMPPStream alloc] init];
    xmppReconnect = [[XMPPReconnect alloc] init];
    xmppStream.enableBackgroundingOnSocket = YES;
    xmppRosterStorage = [[XMPPRosterCoreDataStorage alloc] init];
    [xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
    
  
}
//连接
-(BOOL)connect{
    if (self.xmppStream == nil) {
        xmppStream = [[XMPPStream alloc] init];
        xmppReconnect = [[XMPPReconnect alloc] init];
        xmppStream.enableBackgroundingOnSocket = YES;
        xmppRosterStorage = [[XMPPRosterCoreDataStorage alloc] init];
        [xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
    }
    if (![self.xmppStream isConnected]) {
        userDefaults = [[NSUserDefaults alloc] init];
        NSString *username = [userDefaults objectForKey:@"USERNAME"];
        NSString *server = [userDefaults objectForKey:@"SERVER"];
        XMPPJID *jid = [XMPPJID jidWithUser:username domain:@"lenovopush" resource:nil];
        [self.xmppStream setMyJID:jid];
        [self.xmppStream setHostName:server];
        [self.xmppStream setHostPort:5222];
        NSError *error = nil;
        if (![xmppStream connectWithTimeout:5.0f error:&error]) {
            NSLog(@"connet Error :%@",[[error userInfo] description]);
            return NO;
        }
    }
    return YES;
}

//断开连接
-(void)disconnect{
    [self goOffline];
    [xmppStream disconnect];
}

//上线
-(void)goOnline{
    XMPPPresence *presence = [XMPPPresence presenceWithType:@"available"];
    [[self xmppStream] sendElement:presence];
}

//下线
-(void)goOffline{
    XMPPPresence *presence = [XMPPPresence presenceWithType:@"unavailable"];
    [[self xmppStream] sendElement:presence];
    
}
//添加好友
/*
 <presence from='juliet@example.com'
 id='h4v1c4kj'
 to='romeo@example.net'
 type='subscribed'/>
 */
-(void)xmppAddFriendSubscribe:(NSString *)name{
    XMPPJID *jid = [XMPPJID jidWithString:[NSString stringWithFormat:@"%@@%@",name,@"lenovopush"]];
    [xmppRoster addUser:jid withNickname:@"nickName"];
}

//删除好友,取消加好友，或者加好友后需要删除
- (void)removeBody:(NSString *)name
{
    XMPPJID *jid = [XMPPJID jidWithString:[NSString stringWithFormat:@"%@@%@",name,@"lenovopush"]];
    [xmppRoster removeUser:jid];
}

#pragma mark - 委托
//连接成功回调
- (void)xmppStreamDidConnect:(XMPPStream *)sender {
    
    passWord = [userDefaults objectForKey:@"PASSWORD"];
    isOpend = YES;
    NSError *error = nil;
    NSString *reg = [userDefaults objectForKey:@"REGISTER"];
    if (reg != nil&&[reg isEqualToString:@"register"]) {//注册
        if (![xmppStream registerWithPassword:passWord error:&error]) {
            NSLog(@"Register Error: %@", [[error userInfo] description]);
        }
    }else{
        if (![xmppStream authenticateWithPassword:passWord error:&error]) {//登陆
            NSLog(@"Authenticate Error: %@", [[error userInfo] description]);
        }
    }
    
    NSLog(@"%@",@"xmppStreamDidConnect");
}

- (void)xmppStream:(XMPPStream *)sender didNotAuthenticate:(NSXMLElement *)error{
    NSLog(@"%@",@"didNotAuthenticate");
}

//验证通过
-(void)xmppStreamDidAuthenticate:(XMPPStream *)sender{
    
    [self goOnline];
    
    [xmppReconnect activate:xmppStream];
    
    xmppRoster = [[XMPPRoster alloc] initWithRosterStorage:xmppRosterStorage];
    [xmppRoster activate:xmppStream];
    [xmppRoster addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [xmppRoster fetchRoster];
    
    NSLog(@"%@",@"xmppStreamDidAuthenticate");
}
//获取完好友列表
- (void)xmppRosterDidEndPopulating:(XMPPRoster *)sender{
    NSLog(@"%@",@"xmppRosterDidEndPopulating");
}
//收到用户状态
/*
 一个 <presence /> 标签的格式一般如下：
 
 <presence from="">
 
 　　<show>这里是显示的内容<show />
 
 　　<status>这里是显示的状态<status />
 
 <presence />
 //好友添加请求则消息体为<presence xmlns="jabber:client" from="test@lenovopush" to="linhao@lenovopush" type="subscribe"/>
 presence 的状态：
 
 available 上线
 
 away 离开
 
 do not disturb 忙碌
 
 unavailable 下线
 */
- (void)xmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence {
    //取得好友状态
    NSString *presenceType = [presence type];
    //当前用户
    NSString *userId = [[sender myJID] user];
    //在线用户
    NSString *presenceFromUser = [[presence from] user];
    if (![presenceFromUser isEqualToString:userId]) {
        if ([presenceType isEqualToString:@"available"]) {
            NSLog(@"%@",@"available");
        }else if ([presenceType isEqualToString:@"unvailable"]){
            NSLog(@"%@",@"unvailable");
        }else if ([presenceType isEqualToString:@"subscribed"]) {//处理加好友
             NSLog(@"%@",@"add sucess");
            XMPPJID *jid = [XMPPJID jidWithString:[NSString stringWithFormat:@"%@",[presence from]]];
            [xmppRoster acceptPresenceSubscriptionRequestFrom:jid andAddToRoster:YES];
        }
    }
}

//接收到消息
/*
 当接收到 <message /> 标签的内容时，XMPPFramework 框架回调该方法
 
 根据 XMPP 协议，消息体的内容存储在标签 <body /> 内
 //    <message xmlns="jabber:client" id="JyebH-103" to="62275004d76f4e64affe38f48ebe30cb@www.talk.com/26a9fe46" type="groupchat" from="room2@conference.www.talk.com/tjx"><body>gg</body><x xmlns="jabber:x:event"><offline/><delivered/><displayed/><composing/></x></message>
 //    <message id="JyebH-110" to="luorc@www.talk.com" from="tjx@www.talk.com/Spark 2.6.3" type="chat"><body>dddd</body><thread>FtWwwk</thread><x xmlns="jabber:x:event"><offline/><composing/></x></message>
 */
- (void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message {
    NSString *messageBody = [[message elementForName:@"body"] stringValue];
    NSString *messageFrom = [[message attributeForName:@"from"] stringValue];
    NSLog(@"messageBody%@",messageBody);
    NSLog(@"messageFrom%@",messageFrom);
}

//获取好友列表
/*
 一个 IQ 响应：
 
 <iq type="result"
 
 　　id="1234567"
 
 　　to="xiaoming@example.com">
 
 　　<query xmlns="jabber:iq:roster">
 
 　　　　<item jid="xiaoyan@example.com" name="小燕" />
 
 　　　　<item jid="xiaoqiang@example.com" name="小强"/>
 
 　　<query />
 
 <iq />
 
 type 属性，说明了该 iq 的类型为 result，查询的结果
 
 <query xmlns="jabber:iq:roster"/> 标签的子标签 <item />，为查询的子项，即为 roster
 
 item 标签的属性，包含好友的 JID，和其它可选的属性，例如昵称等。
 */

/*
 获取所有房间
 <iq xmlns="jabber:client" type="result" id="1234567" from="conference.lenovopush" to="test1@lenovopush/b0f10cb4">
 <query xmlns="http://jabber.org/protocol/disco#items">
    <item jid="room2@conference.lenovopush" name="room2"/>
    <item jid="room3@conference.lenovopush" name="room3"/>
    <item jid="room4@conference.lenovopush" name="room4"/>
 </query>
 </iq>
 */
- (BOOL)xmppStream:(XMPPStream *)sender didReceiveIQ:(XMPPIQ *)iq {
    if ([@"result" isEqualToString:iq.type]) {
        NSXMLElement *query = iq.childElement;
        if ([@"query" isEqualToString:query.name]) {
            NSArray *items = [query children];
            for (NSXMLElement *item in items) {
                NSString *jid = [item attributeStringValueForName:@"jid"];
                XMPPJID *xmppJID = [XMPPJID jidWithString:jid];
                NSLog(@"%@",xmppJID);
            }
        }
    }
    return YES;
}

//注册成功
- (void)xmppStreamDidRegister:(XMPPStream *)sender{
    NSLog(@"%@",@"注册成功");
    [userDefaults setObject:@"" forKey:@"REGISTER"];
}

//注册失败
- (void)xmppStream:(XMPPStream *)sender didNotRegister:(NSXMLElement *)error{
    NSLog(@"%@",@"注册失败");
    [userDefaults setObject:@"" forKey:@"REGISTER"];
}
@end
